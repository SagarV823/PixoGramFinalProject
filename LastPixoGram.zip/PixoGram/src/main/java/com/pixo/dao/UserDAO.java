package com.pixo.dao;

import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UserComments;

import java.util.List;

import com.pixo.bean.AccountDetails;
import com.pixo.bean.Followers;

public interface UserDAO {

	public boolean registerUser(AccountDetails user);
	public boolean authenticate(String email,String password);
	public boolean userExistence(String email);
	
	public AccountDetails getUser(String email);
	public List<AccountDetails> getUsers(String name);
	public AccountDetails getUserDetails(int id);
	
	
	public boolean uploadMedia(MyMedia myMedia);
	
	public ProfilePicture showImage(int userId);
	public List<MyMedia> showMedia(int id);
	
	public boolean addComment(UserComments cmt);
	public List<UserComments> showComments(int picId);
	
	public boolean updateUser(int id,String userName,String lastname,String password,String emailID);
			
	public ProfilePicture showProfile(int id);
	
	public boolean Follow(Followers followers);
	public boolean unFollow(int followerId,int followingId);
	public List<Followers> myFollowers(int myId);
	public List<Followers> meFollowing(int myId);
	public boolean checkFollow(int followerId, int followingId);
	
	public boolean uploadProfilePicture(ProfilePicture pic);
	public boolean checkDP(int userId);	
	public boolean updateDP(int userId);
	
	public boolean blockUser(int blockerId,int blockedId);
}
