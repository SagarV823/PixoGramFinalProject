package com.pixo.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BlockList {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bId;
	private int blockerId;
	private int blockedId;
	public int getbId() {
		return bId;
	}
	public void setbId(int bId) {
		this.bId = bId;
	}
	public int getBlockerId() {
		return blockerId;
	}
	public void setBlockerId(int blockerId) {
		this.blockerId = blockerId;
	}
	public int getBlockedId() {
		return blockedId;
	}
	public void setBlockedId(int blockedId) {
		this.blockedId = blockedId;
	}
	@Override
	public String toString() {
		return "BlockList [bId=" + bId + ", blockerId=" + blockerId + ", blockedId=" + blockedId + "]";
	}
	
	
}
