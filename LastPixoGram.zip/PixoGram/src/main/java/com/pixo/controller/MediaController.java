package com.pixo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.pixo.bean.AccountDetails;
import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserService;

@Controller
public class MediaController {

	@Autowired
	public UserService userService;
	
	@Autowired
	public UserDAO userDAO;
	
	static Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value = "uploadPicture", method = RequestMethod.POST)
    public ModelAndView UploadProfilePicture(HttpServletRequest request,@RequestParam CommonsMultipartFile[] profilePicture) throws Exception {
          ModelAndView mv=new ModelAndView();
          int userId=(int)request.getSession().getAttribute("UserId");
          System.out.println("here id is :"+userId);
          boolean checkpic=userDAO.checkDP(userId);
          System.out.println("checkpic"+checkpic);
          if(checkpic==false){
        if (profilePicture != null && profilePicture.length > 0) {
            for (CommonsMultipartFile aFile : profilePicture)
            {      
                System.out.println("Saving file: " + aFile.getOriginalFilename());
                userId=(int)request.getSession().getAttribute("UserId"); 
                ProfilePicture pic = new ProfilePicture();
                pic.setFileName(aFile.getOriginalFilename());
                pic.setData(aFile.getBytes());
                pic.setUserId(userId);
                boolean result=userDAO.uploadProfilePicture(pic);
                if(result)
                {
                	mv.addObject("status","Uploaded succesfully!");
                	mv.setViewName("Welcome");
                }
            }
        }
        }
          else{
        	  boolean deleteoldpic=userDAO.updateDP(userId);
        	  if(deleteoldpic==true)
        	  {
        		  if (profilePicture != null && profilePicture.length > 0) {
                  for (CommonsMultipartFile aFile : profilePicture)
                  {      
                      System.out.println("Saving file: " + aFile.getOriginalFilename());
                      userId=(int)request.getSession().getAttribute("UserId"); 
                      ProfilePicture pic = new ProfilePicture();
                      pic.setFileName(aFile.getOriginalFilename());
                      pic.setData(aFile.getBytes());
                      pic.setUserId(userId);
                      boolean result=userDAO.uploadProfilePicture(pic);
                      if(result)
                      {
                      	mv.addObject("status","Uploaded succesfully!");
                      	mv.setViewName("Welcome");
                      }
                  }
        		}
        	  }
          }
        return mv;
    }
 @RequestMapping(value = "showImage")
 public ModelAndView showImage(HttpServletRequest request, HttpServletResponse response){	
		ModelAndView mv=new ModelAndView();	
    	HttpSession session=request.getSession();
    	int userId=(int)request.getSession().getAttribute("UserId"); 
    	ProfilePicture picture=userDAO.showImage(userId);
    	int picId=picture.getId();
    	System.out.println("Pic id is "+ picId);
    	response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
        try {
			response.getOutputStream().write(picture.getData());
			response.getOutputStream().close();
		} catch (IOException e) {			
			e.printStackTrace();
		}
        mv.addObject("picture",picture);
    	return mv;
    }
 @RequestMapping(value = "showUserImage")
 public ModelAndView showUserImage(HttpServletRequest request, HttpServletResponse response){	
		ModelAndView mv=new ModelAndView();	
    	HttpSession session=request.getSession();
    	int userId=(int)request.getSession().getAttribute("searchedUserId"); 
    	ProfilePicture picture=userDAO.showImage(userId);
    	int picId=picture.getId();
    	System.out.println("Pic id is "+ picId);
    	response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
        try {
			response.getOutputStream().write(picture.getData());
			response.getOutputStream().close();
		} catch (IOException e) {			
			e.printStackTrace();
		}
        mv.addObject("picture",picture);
    	return mv;
    }
 @RequestMapping(value = "uploadMedia", method = RequestMethod.POST)
    public ModelAndView uploadMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
          ModelAndView mv=new ModelAndView();
        if (media != null && media.length > 0) {
            for (CommonsMultipartFile aFile : media)
            {      
                System.out.println("Saving file: " + aFile.getOriginalFilename());
                int userId=(int)request.getSession().getAttribute("UserId"); 
                MyMedia myMedia=new MyMedia();
                myMedia.setMedia(aFile.getBytes());
                myMedia.setTitle(title);
                myMedia.setDescription(description);
                myMedia.setTag(tags);
                myMedia.setUserId(userId);
                boolean result=userDAO.uploadMedia(myMedia);
                if(result)
                {
                	mv.addObject("status","Uploaded succesfully!");
                	mv.setViewName("UploadSingle");
                }
            }
        }	  
        return mv;
    }
 @RequestMapping(value = "uploadMultipleMedia", method = RequestMethod.POST)
    public ModelAndView uploadMultipleMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
          ModelAndView mv=new ModelAndView();
        if (media != null && media.length > 0) {
            for (CommonsMultipartFile aFile : media)
            {      
                System.out.println("Saving file: " + aFile.getOriginalFilename());
                int userId=(int)request.getSession().getAttribute("UserId"); 
                MyMedia myMedia=new MyMedia();
                myMedia.setMedia(aFile.getBytes());
                myMedia.setTitle(title);
                myMedia.setDescription(description);
                myMedia.setTag(tags);
                myMedia.setUserId(userId);
                boolean result=userDAO.uploadMedia(myMedia);
                if(result)
                {
                	mv.addObject("status","Uploaded succesfully!");
                	mv.setViewName("UploadMultiple");
                }
            }
        }	  
        return mv;
    }
 @RequestMapping("myMedia")
	public ModelAndView MyMedia(HttpServletRequest request, HttpServletResponse response){
	 System.out.println("In myMedia Func");
	 ModelAndView mv=new ModelAndView();
	 List<MyMedia> allMedia=new ArrayList<MyMedia>();
	  	HttpSession session=request.getSession();
 	String emailId=(String)request.getSession().getAttribute("EmailId"); 
 	System.out.println("In myMedia Func email "+emailId);
 	AccountDetails user=userService.getUser(emailId);
 	
 	int id=user.getId();
 	System.out.println("ID is "+ id);
 	String fname=user.getFirstName();
		String lname=user.getLastName();
 	mv.addObject("userid",id);
 	mv.addObject("username",fname);
		mv.addObject("lastname",lname);
 	
 	System.out.println("Here ");
 	
 	//allMedia=userDAO.showMedia(id);	    	
 	/*for(com.pixo.bean.MyMedia l:allMedia){	    		
 		response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	       try {
			response.getOutputStream().write(l.getMedia());
				//response.getOutputStream().close();				
	        	mv.addObject("response",response);
			} catch (IOException e) {			
				e.printStackTrace();
			}	    
 	}	 */
 	mv.addObject("allMedia",allMedia);
 	System.out.println("After adding the whole table to list!");
 	mv.setViewName("AllMedia");
 	return mv;		 
}
 
 
}
