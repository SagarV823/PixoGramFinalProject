package com.pixo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UserComments;
import com.pixo.bean.AccountDetails;
import com.pixo.bean.Followers;

@Repository("UserDAO")
public class UserDAOImpl implements UserDAO {

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	public UserDAOImpl() {
    }

	public UserDAOImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
	
	@Transactional
	public boolean registerUser(AccountDetails user) {
		
		Session session=null;
		try{
			session=sessionFactory.getCurrentSession();
			session.save(user);
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
		
	}

	@Transactional
	public boolean authenticate(String email, String password) {
		Session session=null;
		try{
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from AccountDetails where emailId=? and password=?");
		query.setParameter(0,email);
		query.setParameter(1,password);
		AccountDetails user=(AccountDetails)query.getSingleResult();
		}
		catch(NoResultException e)
		{
			return false;
		}
		return true;
	}

	@Transactional
	public AccountDetails getUser(String email) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from AccountDetails where emailId=?");
		query.setParameter(0,email);
		AccountDetails user=(AccountDetails)query.getSingleResult();
		return user;
	}

	@Transactional
	public boolean uploadProfilePicture(ProfilePicture pic) {
		sessionFactory.getCurrentSession().save(pic);
		return true;	
	}

	@Transactional
	public ProfilePicture showImage(int id) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from ProfilePicture where userId=?");
		query.setParameter(0,id);
		ProfilePicture file=(ProfilePicture)query.getSingleResult();
		return file;	
	}

	@Transactional
	public boolean uploadMedia(MyMedia myMedia) {
		sessionFactory.getCurrentSession().save(myMedia);
		return true;
	}
	
	@Transactional
	public List<MyMedia> showMedia(int id) {
		System.out.println("Here i am");
		List<MyMedia> allMedia=new ArrayList<>();
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from MyMedia where userId=?");
		query.setParameter(0,id);
		allMedia=query.getResultList();
		return allMedia;
	}

	@Transactional
	public boolean addComment(UserComments cmt) {	
			Session session=sessionFactory.getCurrentSession();
			session.persist(cmt);		
		return true;
	}

	@Transactional
	public List<UserComments> showComments(int picId) {
		
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from UserComments where picId=?");
		query.setParameter(0,picId);
		System.out.println(picId);
		List<UserComments> comments=query.getResultList();
		for(UserComments c:comments)
		{
			System.out.println(c.getUserComment());
		}
		return comments;
		
	}

	@Transactional
	public boolean updateUser(int id,String userName,String lastname, String password, String emailID) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		System.out.println("update here");
		Query query=session.createQuery("from AccountDetails where id=?");
		query.setParameter(0,id);
		AccountDetails user=(AccountDetails)query.getSingleResult();
		System.out.println("Update here 2");
		
		if(!userName.equals(",,empty"))
			user.setFirstName(userName);
		if(!lastname.equals(",empty"))
			user.setLastName(lastname);
		if(!emailID.equals(",empty"))
			user.setEmailId(emailID);
		if(!password.equals(",empty"))
			user.setPassword(password);						
		return true;
	}
	
	@Transactional
	public List<AccountDetails> getUsers(String name) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=null;
		String firstname="";
		String lastname="";
		String checkString=name; 		 
        if(checkString.contains(" ")){
        	String fullname =name;
        	String[] actualname = fullname.split(" ", 2);
        	firstname=actualname[0];
        	lastname=actualname[1]; 
        	query=session.createQuery("from AccountDetails where firstName=? and lastName=?");
        	query.setParameter(0,firstname);
    		query.setParameter(1, lastname);
        }
        else{
        	firstname=name;
        	query=session.createQuery("from AccountDetails where firstName=?");
        	query.setParameter(0, firstname);
        }				
			
		List<AccountDetails> users=query.getResultList();
		for(AccountDetails u:users)
		{
			System.out.println(u.getLastName());
		}
		return users;
	}

	@Transactional
	public AccountDetails getUserDetails(int id) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from AccountDetails where id=?");
		query.setParameter(0,id);
		AccountDetails user=(AccountDetails)query.getSingleResult();
		return user;
	}

	@Transactional
	public ProfilePicture showProfile(int id) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from ProfilePicture where userId=?");
		query.setParameter(0,id);
		ProfilePicture file=(ProfilePicture)query.getSingleResult();
		return file;	
	}

	@Transactional
	public boolean Follow(Followers followers) {
		Session session=sessionFactory.getCurrentSession();
		session.persist(followers);		
	return true;
	}

	@Transactional
	public boolean unFollow(int followerId, int followingId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Followers where followerId=? and followingId=?");
		query.setParameter(0, followerId);
		query.setParameter(1, followingId);
		Followers followers=(Followers)query.getSingleResult();
		session.delete(followers);
		return true;
	}

	@Transactional
	public List<Followers> myFollowers(int myId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Followers where followingId=? and followerId!=?");
		query.setParameter(0,myId);
		query.setParameter(1, myId);
		List<Followers> follos=query.getResultList();
		for(Followers f:follos)
		{
			System.out.println(f.getFollowerName());
		}
		return follos;
	}

	@Transactional
	public List<Followers> meFollowing(int myId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Followers where followerId=? and followingId!=?");
		query.setParameter(0,myId);
		query.setParameter(1, myId);
		List<Followers> follos=query.getResultList();
		for(Followers f:follos)
		{
			System.out.println(f.getFollowingName());
		}
		return follos;
	}

	@Transactional
	public boolean userExistence(String email) {		
		try{
			Session session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from AccountDetails where emailId=?");
			query.setParameter(0,email);
			AccountDetails accountDetails=(AccountDetails)query.getSingleResult();
		}
		catch(NoResultException e)
		{
			return false;
		}
		return true;
	}

	@Transactional
	public boolean checkFollow(int followerId, int followingId) {
		try{
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Followers where followerId=? and followingId=?");
		query.setParameter(0,followerId);
		query.setParameter(1, followingId);
		Followers follos=(Followers)query.getSingleResult();
		}		
		catch(NoResultException e)
		{
			return false;
		}
		return true;
		}

	@Transactional
	public boolean checkDP(int userId) {
		try{
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from ProfilePicture where userId=?");
		query.setParameter(0, userId);
		query.getSingleResult();
		}
		catch(NoResultException e)
		{
			System.out.println("no entity");
			return false;
		}
		return true;				
	}

	@Transactional
	public boolean updateDP(int userId) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from ProfilePicture where userId=?");
		query.setParameter(0,userId);
		ProfilePicture file=(ProfilePicture)query.getSingleResult();
		session.delete(file);
		return true;
	}
		
}
