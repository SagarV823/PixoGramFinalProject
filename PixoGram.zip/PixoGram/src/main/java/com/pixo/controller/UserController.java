package com.pixo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UserComments;
import com.pixo.bean.AccountDetails;
import com.pixo.bean.Followers;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	public UserService userService;
	
	@Autowired
	public UserDAO userDAO;
	
	static Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value="registerUser",method=RequestMethod.GET)
	public ModelAndView registerUser(@ModelAttribute AccountDetails user){
		ModelAndView mv=new ModelAndView();
		boolean flagName=false,flagEmail=false,flagPass=false;
		//Validating
		String firstName=user.getFirstName();
		String lastName=user.getLastName();		
		String password=user.getPassword();
		String confirmpass=user.getConPassword();
		System.out.println("password "+password+" "+ "confirm "+confirmpass);
		boolean allFirstLetters = firstName.chars().allMatch(Character::isLetter);
		boolean allLastLetters = lastName.chars().allMatch(Character::isLetter);
		boolean userexist=userService.userExistence(user.getEmailId());
		if(!password.equals(confirmpass))
		{
			flagPass=true;
			logger.info("Validation Failed");
			logger.info("*Password Missmatch");
			mv.addObject("statuspass","*Password dosen't match");
		}
		if(!allLastLetters){
			flagName=true;
			logger.info("Validation Failed");
			logger.info("**Last Name cannot contain number or special characters");
			mv.addObject("statuslastname","*Numbers or special characters are not allowed");
			}
		if(!allFirstLetters){
				flagName=true;
				logger.info("Validation Failed");
				logger.info("**First Name cannot contain number or special characters");
				mv.addObject("statusfirstname","*Numbers or special characters are not allowed");
			}
		if(userexist==true)
		{
			flagEmail=true;
			logger.info("Validation Failed");
			logger.info("*User exists");
			mv.addObject("statusemail","*User already exists");
		}
		if(flagName==false&&flagEmail==false&&flagPass==false)
		{	
			boolean result=userService.registerUser(user);
			if(result)
				{
					logger.info("Registration successful !");
					mv.addObject("Registerstatus","Successfully registered! Proceed to login Page!");
					mv.setViewName("Login");
				}			
			else
				{
					logger.warn("Registration failed ! Check EmailId or Password ...");
					mv.setViewName("SignUp");
				}				
		}
		else
		{
			mv.setViewName("SignUp");
		}
		return mv;
	}
	
	@RequestMapping(value="loginUser",method=RequestMethod.POST)
    public ModelAndView UserAuthentication(@RequestParam("EmailId") String emailId,@RequestParam("Password") String password,HttpServletRequest request){	
		
		logger.info("Credential A Authenticating ...");	      	      
	  	ModelAndView mv=new ModelAndView();
    	boolean result=userService.authenticate(emailId, password);
    	HttpSession session=request.getSession();
    	session.setAttribute("EmailId", emailId);
    	
    	if(result){
    		logger.info("Authentication Successful ...");
    		AccountDetails user=userService.getUser(emailId);
    		String fname=user.getFirstName();
    		String lname=user.getLastName();
    		int id=user.getId();
    		session.setAttribute("UserId", id);
    		mv.addObject("userid",id);
    		mv.setViewName("Welcome");
    		mv.addObject("username",fname);
    		mv.addObject("lastname",lname);
    	}
    	else{	
    		logger.warn("Authentication failed ! Wrong Email or Password ...");	
    		mv.addObject("status","Wrong Email or Password!");
			mv.setViewName("Login");
    	}   	
    	return mv;
    }
	
	@RequestMapping(value="home")
    public ModelAndView Home(HttpServletRequest request){	
		
		logger.info("Credential A Authenticating ...");	      	      
	  	ModelAndView mv=new ModelAndView();
    	HttpSession session=request.getSession();
    	String emailId=(String)request.getSession().getAttribute("EmailId");
    	session.setAttribute("EmailId", emailId);    	    
    		AccountDetails user=userService.getUser(emailId);
    		String fname=user.getFirstName();
    		String lname=user.getLastName();
    		int id=user.getId();
    		session.setAttribute("UserId", id);
    		mv.addObject("userid",id);
    		mv.setViewName("Welcome");
    		mv.addObject("username",fname);
    		mv.addObject("lastname",lname); 	    	
    		logger.warn("Home Page");	   	
    	return mv;
    }
	
	 
	 @RequestMapping(value="welcome")
	    public ModelAndView WelcomePage(HttpServletRequest request){	
			
			logger.info("Credential A Authenticating ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("emailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String fname=user.getFirstName();
    		String lname=user.getLastName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	mv.addObject("userid",id);
	    	mv.setViewName("Welcome");
	    	mv.addObject("username",fname);
    		mv.addObject("lastname",lname);   	
	    	return mv;
	    }
	 
	 @RequestMapping(value="likesComments")
	 public ModelAndView likesCommentsPage(HttpServletRequest request){				
			logger.info("Redirecting to comments page ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String fname=user.getFirstName();
    		String lname=user.getLastName();
	    	int id=user.getId();
	    	ProfilePicture picture=userDAO.showImage(id);
	    	String title=picture.getFileName();
	    	session.setAttribute("UserId", id);
	    	mv.addObject("userid",id);
	    	mv.addObject("title",title);
	    	mv.setViewName("LikesComments");
	    	mv.addObject("username",fname);
    		mv.addObject("lastname",lname);   
	    	
	    	
	    	int picId=picture.getId();
	    	System.out.println("Pic "+picId);
	    	List<UserComments> allcomments=userService.showComments(picId);
	    	mv.addObject("AllComments",allcomments);
	    	mv.setViewName("LikesComments");
	    	return mv;
	    }
	 	 	
	 @RequestMapping(value="addComment", method = RequestMethod.POST)
	 	public ModelAndView addComment(HttpServletRequest request, HttpServletResponse response,@RequestParam("comment") String comment) {
		 ModelAndView mv=new ModelAndView();
		 UserComments cmt=new UserComments();
		 
		 HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);	
	    	int userid=user.getId();
	    	ProfilePicture picture=userDAO.showImage(userid);
	    	String title=picture.getFileName();
	    	int picid=picture.getId();
	    	session.setAttribute("UserId", userid);
	    	cmt.setUserId(userid);
	    	cmt.setPicId(picid);			 
	    	cmt.setUserComment(comment);
	    	userService.addComment(cmt);
	    	mv.setViewName("LikesComments");
	    	mv.addObject("title",title);
	    	mv.addObject("status","comment added!");
		 return mv;
	 }
	 @RequestMapping(value="accountUpdate")
	public ModelAndView accountUpdatePage(HttpServletRequest request){
		 ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String fname=user.getFirstName();
	    	String lname=user.getLastName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	mv.addObject("username",fname);
    		mv.addObject("lastname",lname);
    		mv.setViewName("AccountUpdate");
		 return mv;
	}
	 @RequestMapping(value="updateUser",method=RequestMethod.POST)
	 public ModelAndView UpdateUser(HttpServletRequest request,@RequestParam("username") String username,@RequestParam("lastname") String lastname,@RequestParam("password") String password,
			 @RequestParam("email") String email){	
			
			logger.info("Updating user details ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String fname=user.getFirstName();
    		String lname=user.getLastName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	boolean result=false;
	    	System.out.println("name is "+username);
			System.out.println("password is "+password);
			System.out.println("lastname is "+lastname);
			System.out.println("email is "+email);
	    	result=userService.updateUser(id, username,lastname, password, email);
	    	System.out.println("result = "+result);
	    	mv.addObject("userid",id);
	    	if(result)
	    		mv.addObject("status","updated successfully!");
	    	mv.addObject("username",fname);
    		mv.addObject("lastname",lname);  	
	    	mv.setViewName("AccountUpdate");
	    	return mv;
	    }
	 
	
	 @RequestMapping(value="search",method=RequestMethod.POST)
	 public ModelAndView SearchUser(HttpServletRequest request,@RequestParam("username") String userName){	
			
			logger.info("Searching user details ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String fname=user.getFirstName();
    		String lname=user.getLastName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	mv.addObject("userid",id);
	    	mv.addObject("username",fname);
    		mv.addObject("lastname",lname);
	    	
	    	//Search Code
	    	List<AccountDetails> users=userService.getUsers(userName);
	    	mv.addObject("users",users);	    	
	    	mv.setViewName("SearchResults");
	    	return mv;
	    }
	 @RequestMapping(value="userDetails")
	 public ModelAndView ViewProfile(HttpServletRequest request,@RequestParam("id") int userId,HttpServletResponse response){	
			
			logger.info("Searching user details ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails myself=userService.getUser(emailId);
	    	String fname=myself.getFirstName();
    		String lname=myself.getLastName();
    		mv.addObject("username",fname);
    		mv.addObject("lastname",lname); 
    		
	    	int id=userId;
	    	AccountDetails user=userService.getUserDetails(id);
	    	int profileId=user.getId();
	    	session.setAttribute("searchedUserId", id);	      	
	    	System.out.println(user.getFirstName());
	    	mv.addObject("userdetails",user);	    	
	    	mv.setViewName("UserDetails");
	    	return mv;
	    }
	 
	 
	 
}
